/**
 * 
 */
package java1;

/**
 * @author limca
 *
 */
public class QueueExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		

	}

}
