package soliddesign.dependecnyinjection;

import java.util.HashMap;

public interface ProductRepository {

	public HashMap<String , String> getallProdcuts();
}
