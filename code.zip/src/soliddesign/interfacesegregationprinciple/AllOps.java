package soliddesign.interfacesegregationprinciple;

public interface AllOps {

	public int getsum(int a,int b) ;
	public int getsubtract(int a,int b) ;
	public int getmultiply(int a,int b) ;
	public double getlog(int a);
	public double getSine(int a);
	public double getCos(int a);
	public double getlTan(int a);
	
}
