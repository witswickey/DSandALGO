package soliddesign.interfacesegregationprinciple;

public interface BasicAirthMaticTwoOps {

	public int getsum(int a,int b) ;
	public int getsubtract(int a,int b) ;
	public int getmultiply(int a,int b) ;
}
