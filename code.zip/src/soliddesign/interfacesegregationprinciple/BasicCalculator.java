package soliddesign.interfacesegregationprinciple;

public class BasicCalculator implements BasicAirthMaticTwoOps {// not implemented AllOps

	@Override
	public int getsum(int a, int b) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getsubtract(int a, int b) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getmultiply(int a, int b) {
		// TODO Auto-generated method stub
		return 0;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
