package soliddesign.interfacesegregationprinciple;

public interface SciencetificOps {

	public double getlog(int a);
	public double getSine(int a);
	public double getCos(int a);
	public double getlTan(int a);
}
