package soliddesign.liskovsubsitituionPrinciple;

public  class Product {
	public static double discount=20;
	public double getdiscount() {
		return discount;
	}
}
