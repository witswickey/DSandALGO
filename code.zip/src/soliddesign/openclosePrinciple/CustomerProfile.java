package soliddesign.openclosePrinciple;

public interface CustomerProfile {

	public boolean isLoyal();
}
