package soliddesign.openclosePrinciple;

public class HealthInsuranceCustomerProfile  implements CustomerProfile{

	public boolean isLoyal() {
		return true;
	}
}
