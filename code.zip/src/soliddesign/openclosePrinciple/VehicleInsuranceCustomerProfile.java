package soliddesign.openclosePrinciple;

public class VehicleInsuranceCustomerProfile implements CustomerProfile {
	public boolean isLoyal() {
		return false;
	}
}
